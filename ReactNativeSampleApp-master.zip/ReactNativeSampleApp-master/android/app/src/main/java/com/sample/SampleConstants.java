package com.sample;

public class SampleConstants {
    public static final String APP_PREFS_NAME = "sample-app-prefs";
}
