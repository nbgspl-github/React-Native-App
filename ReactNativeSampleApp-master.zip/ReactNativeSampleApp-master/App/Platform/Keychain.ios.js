import * as KeyChain from 'react-native-keychain';

export default KeyChain;
