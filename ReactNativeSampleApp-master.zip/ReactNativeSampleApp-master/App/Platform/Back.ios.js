const Back = {
  setNavigator(navigator) {
  },
};

export default Back;
