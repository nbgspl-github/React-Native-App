// base translations that get translated

export default {

};
