// these do not get translated, mostly for values or something

export default {

};
